#include<iostream>
using namespace std;
class College{
	int roll;
	string name,course;
	public:
		College(){
		course="Computer Engineering";
		}
		College(College &c1){
			name=c1.name;
			roll=c1.roll;
			course=c1.course;
		}
		void func(){
			cout<<"enter roll no and name:";
			cin>>roll>>name;
			cout<<"roll:"<<roll<<" name:"<<name<<course;
		}
};
int main(){
	College n;
	n.func();
	College n2(n);
	n2.func();
}

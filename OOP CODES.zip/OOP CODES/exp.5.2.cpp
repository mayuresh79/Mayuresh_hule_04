#include<iostream>
using namespace std;
class Student{
	int roll;
	string name;
	public:
		Student(int r,string n){
		roll=r;
		name=n;
		}
		void func(){
			cout<<"roll:"<<roll<<" name:"<<name;
		}
};
int main(){
	Student n(5,"Aman");
	n.func();
}
